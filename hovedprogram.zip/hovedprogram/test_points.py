import csv
import sys
from pprint import pprint
import numpy as np

# Parametrs for geerating test points
w = 1024# 1024 in this project
h = 576 # 576 in thi s project
w_points = 20
h_points = 10

w_delta = int(w / w_points) #avoid overflow
h_delta = int(h / h_points)

# Generate test points horizontal axis
w_list = [np.nan]*w_points
for i in range(w_points):
    if i==0: w_list[0] = ['x', w_delta, np.nan]
    else: w_list[i] = ['x', w_list[i-1][1] + w_delta, np.nan]

# Generate test points vertical axis
h_list = [np.nan]*h_points
for i in range(h_points):
    if i==0: h_list[0] = ['y', h_delta, np.nan]
    else: h_list[i] = ['y', h_list[i-1][1] + h_delta, np.nan]


point_data = w_list + h_list

with open('servo_map.csv', 'w') as f:
    w = csv.writer(f)
    w.writerow(['axis', 'px', 'angle'])
    w.writerows(point_data)

pprint(point_data)
