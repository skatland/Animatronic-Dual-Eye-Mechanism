#!/bin/bash

cd /home/buzz/Python
source /home/buzz/Python/eye_project/bin/activate
python /home/buzz/Python/eye_projectv4.py
