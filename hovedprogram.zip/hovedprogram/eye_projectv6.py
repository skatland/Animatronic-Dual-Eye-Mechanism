# -*- coding: utf-8 -*-
"""
Created on Sun May  4 14:48:05 2025

"""
import csv
import cv2
import cv2.data

from datetime import datetime
import json

import math
import matplotlib.pyplot as plt
import mplcursors

import numpy as np
import os

import pandas as pd
from picamera2 import Picamera2
from PIL import Image, ImageTk

import serial
import sys

import threading
import time
from time import sleep
from typing import Literal, Optional, Tuple
from tkinter import PhotoImage
import tkinter as tk
import tkinter.font as tkfont
from tkinter import ttk


# Plot function available if dev wants to plot theta(angle) for function calibrated tracking
theta_df = pd.DataFrame(columns=['theta_v', 'angle_v', 'theta_h', 'angle_h']) 

h_window_global = None # These are set as the frame size of the porgram in App.__init__
w_window_global = None

# Size of image array used for tracking
W_IMG = 1024 #TODO: Make responsive
H_IMG = 576

# Servo settings constants
SERVO_SETTINGS_PATH = 'servo_settings.json'
EYE_SERVO_V = 'Servo Vertical'      # Servoname of servo used for tracking
EYE_SERVO_H = 'Servo Horizontal'    # Servo used for tracking

# File used to save tracking data
TRACKING_CSV_PATH = 'tracking.csv'

# Tracking constants
CALIBRATED_TRACKING = 'Calibrated'
CALIBRATION_CSV_PATH = 'servo_map_close.csv'
CALIBRATION_HEADERS = ['axis', 'px', 'angle']

LINEAR_TRACKING = 'Linear'

FUNCTION_TRACKING = 'Function'
FUNCTION_CONSTANT_K = 3


TRACKING_MODES = [LINEAR_TRACKING, CALIBRATED_TRACKING, FUNCTION_TRACKING]


###################################################################################################
###################################################################################################
###################################################################################################       
################################ Utilities and Drivers ############################################
###################################################################################################
###################################################################################################
###################################################################################################


###################################################################################################       
################################ Logger ########################################################
###################################################################################################

class Logger(): 
    '''
    Logger Class is handles writing to and reading from the logg. 
    It is closely tied to the settings page.
    '''
    
    def __init__(self, path='logg.txt', fresh=False):
        
        self.path = path
        self.id = 0                 # Index of last logg entry
        self.settings_page = None   # The setting page object adds itself here

        try:
            # Initialise logg, 
            with open(path, 'r') as f: # If there's data

                lines = f.readlines()

                # Get the id of the latest logg-entry, to start counting
                if len(lines) > 0:

                    last_line = lines[-1]

                    try:
                        id_str = last_line.split('\t')[0]
                        self.id = int(id_str) + 1
                    
                    # If the index of the last entry cannot be interpreted data is corrupted, and the logg is reset
                    # Currently the logg does not include data that it is crucial to keep.
                    # TODO: Add corrupted logg to its own file.
                    except (IndexError, ValueError) as e:
                        print(type(e).__name__, ':\n', e)
                        self.reset()

            if fresh: # Create new logg
                self.reset()

        except FileNotFoundError:

            with open(path, 'w'):
                pass #make file

    def add_entry(self, message):
        '''
        Add a entry to the logg file and tree-view.
        '''
        # Get time stamp
        tid = datetime.now().strftime("%Y-%m-%d %H:%M")

        # Append new logg entry to logg file
        with open(self.path, 'a') as f:
            f.write(f'{self.id}\t{tid}\t{message}\n')
        
        # Add the logg-entry to the treeview
        self.settings_page.add_logg_entry(id=self.id, tid=tid, message=message)
        self.id += 1


    def reset(self):
        '''
        Delete all data in the logg file and empty the treeview in settings-page.
        '''
        
        self.id = 0

        with open(self.path, 'w'):
            pass

        for entry in self.settings_page.treeview.get_children():
            self.settings_page.treeview.delete(entry)


    def load_all(self):
        '''
        Retrieves all logg-entries in the logg-file. 
        Returns them as a list of entries (lines), each with three vales [[id, time, message], ...]
        Lines with the wrong format are returned as [Nan, Nan, Nan]
        '''

        with open(self.path, 'r') as f:

            logg_data = []

            for line in f.readlines():

                line_data = line.split('\t')

                # Handle lines with the wrong format
                if len(line_data) != 3:
                    line_data = ['NaN', 'NaN', 'NaN'] 

                logg_data.append(line_data)

        if len(logg_data) < 0:
            return None

        return logg_data

###################################################################################################       
################################ AVR Driver ########################################################
###################################################################################################

class AvrDriver(serial.Serial): #TODO: Listen for ACK/NACK
    '''
    Class that handles communciating with the AVR over serial communication.
    '''

    def __init__(self, baud=9600, port="/dev/ttyS0", channels=10):
        '''
        Channels input is the channels of the PCA9685 controlled by the servo
        '''

        super().__init__(port, baud)          # Start serial commuication

        self.char_delay_s = 0.08                # Delay between each sent character to avoid overloading the AVR
        self.buffer = [None]*channels           # The buffer has a designated slot per servo channel

        self.sending = False                    # Flag - activaly sending over USART
        
        # Start background sending thread
        # Background sender thread stops the char_delay from halting the whole app
        self.running = False                    # Flag - background sending thread running
        self.lock = threading.Lock()
        self.sender_thread = None

        #
        self.channels = channels
        self.channel_index = 0                   # The sender iterates over the buffer
        


    def start(self):
        '''
        Starts the background sending thread.
        '''

        if not(self.running):

            self.running = True
            self.sender_thread = threading.Thread(target=self._process_buffer, daemon=True)
            self.sender_thread.start()
    
    def _send_str(self, message): 
        '''
        Sends a given message over USART.
        Called by the background sending thread.
        '''

        self.sending = True
        
        for c in message:
            c_str = str(c)
            self.write(c_str.encode("utf-8"))
            sleep(self.char_delay_s) #Lets the AVR keep up

        self.sending = False


    def receive_char(self): # Currently not in used, planned to be used in ACK/NACK handling
        '''
        Recieve a character via USART.
        '''
        
        c = self.read().decode("utf-8")
        return c

    
    def send_to_avr(self, channel: int, angle: int): 
        '''
        Add an angle to the buffer position corresponding to the given channel.
        Used by the rest of the program.
        '''  
          
        global programLogg

        message = f'[{channel},{angle}]'
        
        # Add message to buffer
        with self.lock:

            if channel >= self.channels:
                programLogg.add_entry(f"[WARNING] Failed to buffer message for channel: {channel}")
            else:
                self.buffer[channel] = message


    def _process_buffer(self):
        '''
        Iterates over the buffer. Sends and discards any new messages.
        Runs in a separate background thread to avoid halting the app from sending delays.
        '''

        while self.running:

            # Load message
            with self.lock:
                message = self.buffer[self.channel_index]
            
            # If there is a message, send it
            if message: 
                self._send_str(message)
                self.buffer[self.channel_index] = None
            else: sleep(0.01)

            # Proceed to the next index
            self.channel_index += 1
            if self.channel_index >= self.channels: 
                self.channel_index = 0



    def stop(self):
        '''
        Stops the background sender thread. Used upon code conclusion.
        '''

        if self.sender_thread:
            self.running = False
            self.sender_thread.join() # Wait for thread to join main thread

            
            


###################################################################################################       
################################ Servo Driver ########################################################
###################################################################################################

class ServoDriver():
    '''
    Driver that stores all servo_data and handles tracking.
    Simplifies servo-handling for the rest of the program.
    '''
    
    def __init__(self, servos):
        
        # Connect the driver to each servo
        self.servos = servos  # dict with Name: servo_object pairs
        for servo in self.servos.values():
            servo.driver = self

        # Set tracking-mode, default is linear
        self.tracking_mode = LINEAR_TRACKING    # Set by the user interacting with a dropwdown menu in the home frame
        self.calibration_ready = False          # Flag that is sent if a full set of calibration points are loaded


    def track_point(self, point_x, point_y, img_w, img_h):
        global TRACKING_CSV_PATH, programLogg


        ###### Set vertical servo to the right location #############
        servo_v = self.servos[EYE_SERVO_V]

        # Inverse pixel position; in image scale up=0, down=height
        if self.tracking_mode != CALIBRATED_TRACKING:
            point_y = img_h - point_y # This is already handled when calibrated.

        # Convert position to an angle and send to servo
        angle_v = servo_v.imgscale2servoscale(coordinate=point_y, old_min=0, old_max=img_h, mode=self.tracking_mode)
        if angle_v != -1: self.send_angle(EYE_SERVO_V, angle_v)


        ############## Set horizontal servo to the right location #################
        servo_h = self.servos[EYE_SERVO_H]

        # Inverse pixel position; in image scale left=0, down=width
        if self.tracking_mode != CALIBRATED_TRACKING:
            point_x = img_w - point_x # This is already handled when calibrated.

        # Convert position to an angle and send to servo
        angle_h = servo_h.imgscale2servoscale(coordinate=point_x, old_min=0, old_max=img_w, mode=self.tracking_mode)
        if angle_h != -1: self.send_angle(EYE_SERVO_H, angle_h)


        # Report errors in scaling
        if angle_v == -1 or angle_h == -1:
            programLogg.add_entry([f'[ERROR] Unrecognized tracking mode: {self.tracking_mode}.'])

        # Logg coordinate and angles for trouble shooting and documentation
        file_exists = os.path.isfile(TRACKING_CSV_PATH)

        with open(TRACKING_CSV_PATH, mode='a', newline='') as f:
            w = csv.writer(f)

            if not(file_exists):
                w.writerow(['servo', 'img_point', 'img_max', 'servo_angle', 'servo_min', 'servo_max'])
            
            w.writerow([EYE_SERVO_V, point_y, img_h, angle_v, servo_v.min, servo_v.max])
            w.writerow([EYE_SERVO_H, point_x, img_w, angle_h, servo_h.min, servo_h.max])



    def send_angle(self, servo_name, angle):
        '''
        Send an angle to a servo.
        Angle element in scale [0,180]

        '''

        global programLogg
        global avrComms

        servo = self.servos[servo_name]
        angle = servo.check_angle(angle) # Sets new current angle, returns -1 if the angle is the same as the current angle

        # Send angle and channel to communication-driver
        if angle >= 0 and angle <= 180: # If new angle != the last value given
            avrComms.send_to_avr(servo.channel, angle)


    def get_angle(self, servo_name):
        '''
        Returns the current angle of the servo with the given name.
        '''

        servo = self.servos[servo_name]
        return servo.current_angle



class Servo():
    '''
    Stores the data related to each servo, 
    and handles converting picture coordinates to an angle.
    '''

    def __init__(self, name, img_path, channel: int):

        # Set default servo angle limits
        self.min = 0
        self.max = 180
        self.mid = 90

        # Set the current_angle
        self.current_angle = 0  # Startpoint
        self.driver = None      # ServoDriver is added here

        # Set parameters
        self.__name__ = name
        self.channel = channel
        self.img_path = img_path
        self.image = None

        # Load any settings saved in the servo_settings file
        self._load_settings()

    def check_angle(self, angle):
        '''
        Checks if the new calculated angle is equal to the last angle
        that was sent to the avr. 
        Calling this function implies that you intend to send the given angle to the avr.
        Returns -1 or the angle it recieved clamped to the servos max settings.
        '''
        
        angle = np.clip(angle, self.min, self.max)

        if angle == self.current_angle:
            return -1

        self.current_angle = angle
        return angle

    def rescale(self, value, old_max, old_min, new_max, new_min):
        '''
        Returns a given value rescaled [old_min, old_max] -> [new_min, new_max].
        '''

        new_value = new_min + (new_max - new_min)*(value-old_min) / (old_max - old_min)
        return int(round(new_value))
    
    def imgscale2servoscale(self, coordinate: int, old_min: int, old_max: int, clamped=True, mode=LINEAR_TRACKING):
        '''
        Recieves a pixel-position and image-dimension, and returns and angle with a given tracking method. 

        Methods:
        - LINEAR: Use linear scaling, with min, max and mid point of both the image and servo_range
        - FUNCTION: Uses nonlinea atan-based tracking, to attempt to attune for spherical vision.
        - CALIBRATED: Uses linear scaling with a set of calibrated points loaded from an external csv.

        Args:
            coordinate (int): The coordinate (pixel) value to convert.
            old_min (int): Minimum value of the input scale (image range).
            old_max (int): Maximum value of the input scale (image range).
            clamped (int): Whether to clamp the resulting angle within [min, max] bounds. Defaults to True.
            mode (str): The tracking mode to use ('Linear', 'Function', or 'Calibrated').

        Returns:
            A servo angle, calculated with the given tracking method.
            -1, If the calibration method given was invalid.


        '''

        global H_IMG, FUNCTION_CONSTANT_K, LINEAR_TRACKING, FUNCTION_TRACKING, CALIBRATED_TRACKING, CALIBRATION_CSV_PATH

        old_mid = old_min + (old_max - old_min) / 2


       ################ Perform linear tracking #####################
        if mode == LINEAR_TRACKING:

            # Coordinate in LHP
            if coordinate < old_mid:
                angle = self.rescale(coordinate, old_max=old_mid, old_min=old_min, new_max=self.mid, new_min=self.min) # Linear mapping
                if clamped:
                    if angle < self.min: angle = self.min
                    if angle > self.mid: angle = self.mid

             # Coordinate in LRP
            else:
                angle = self.rescale(coordinate, old_max=old_max, old_min=old_mid, new_max=self.max, new_min=self.mid) # Linear mapping
                if clamped:
                    if angle < self.mid: angle = self.mid
                    if angle > self.max: angle = self.max


        ################ Perform function tracking #####################
        elif mode == FUNCTION_TRACKING:
            # Left_shifts the pixel position, so that the midpoint of the img is zero, calculates a +-90 angle which is shifted to a 0-180 angle

            # Find the max absolut angle allows based on which half of the image the position is in
            if coordinate < old_mid:    theta_max = abs(self.mid - self.min) # abs is safeguard in case of wrong calibration
            else:                       theta_max = abs(self.max - self.mid)


            
            x = abs(coordinate - old_mid)               # Left shift the pixel position
            max_x = (old_max - old_min) / 2             # Find max possible value of left-shifted x
            k = FUNCTION_CONSTANT_K                     # Function constant

            # Calculate angle [0, 1]
            #theta_filtered = math.atan( (x*k/max_x) * (theta_max/math.atan(k)) ) # Original function, did not work with the low k required
            theta_filtered = math.atan( (x*k/max_x) / (math.pi/2))

            # Convert theta value [0, 1], to the angle by calculating deviation from mid point
            if coordinate < old_mid:    angle = self.mid - theta_filtered * abs((self.mid-self.min)) # abs is a safeguard in case of wrong calibration
            else:                       angle = self.mid + theta_filtered * abs((self.max - self.mid))

            # Optionally: clamp data
            if      clamped and angle < self.min: angle = self.min
            elif    clamped and angle > self.max: angle = self.max

            # Result
            angle = int(round(angle))


            # Plot function available if dev wants to plot theta(angle) for function calibrated tracking
            global theta_df
            if old_max > 600:
                theta_df.loc[len(theta_df)] = [np.nan, np.nan, theta_filtered, angle]
            else:
                theta_df.loc[(len(theta_df))] = [theta_filtered, angle, np.nan, np.nan]
            
        
        ################ Perform calibration tracking #####################
        elif mode == CALIBRATED_TRACKING and self.driver.calibration_ready:
            # Linear mapping using a set of calibrated test points
            # If self.driver.calibration_ready is set, the tracking frame has validated that the calibration is complete and correct

            # Read calibration data
            df = pd.read_csv(CALIBRATION_CSV_PATH)

            # Determine if the x or y axis is being calibrated
            if old_max > (H_IMG + 100): # Width is 1024 pixels, height is 576 pixels
                df_axis = df[df['axis'] == 'x'].copy()
            else:
                df_axis = df[df['axis'] == 'y'].copy()

            # Sort the calibratin points by pixel position
            df_axis.sort_values(by='px', inplace=True)
            df_axis.reset_index(drop=True, inplace=True)


            # Find the first calibration point with a higher pixel position value than the point being tracked
            ind = 0
            for i, row in df_axis.iterrows():
                if row['px'] > coordinate:
                    ind = i
                    break
                
            
            # Linear interpolation
            if ind == 0: # Edge case min px max angle
                angle = np.interp(coordinate, 
                                  [df_axis['px'].iloc[0], old_max], 
                                  [df_axis['angle'].iloc[0]], self.max)

            elif ind == df_axis.shape[0] -1 : # Edge case max pixel min angle
                angle = np.interp(coordinate, 
                                  [old_min, df_axis['px'].iloc[-1]], 
                                  [self.min, df_axis['angle'].iloc[-1]])

            else:   
                angle = np.interp(coordinate, 
                                  [df_axis['px'].iloc[ind-1], df_axis['px'].iloc[ind]], 
                                  [df_axis['angle'].iloc[ind-1], df_axis['angle'].iloc[ind]])

            
            # Optional clmaping
            if      clamped and angle < self.min: angle = self.min
            elif    clamped and angle > self.max: angle = self.max

            # Set angle
            angle = int(round(angle))
                
 
        # return -1 if invalid tracking method was given
        else:
            return -1


        return angle

    
    def servoscale2scale(self, angle: int, new_min: int, new_max: int):
        '''
        Returns the linear mapping from an angle within the servos angle limits, to
        an angle in a scale [new_min, new_max].

        Returns the new_angle
        '''

        new_angle = self.rescale(angle, old_max=self.max, old_min=self.min, new_max=new_max, new_min=new_min)
        return new_angle

    def load_image(self):
        ''''
        Loads the servo's illustrative image, to the attribute self.image.
        The attribute is set to one if the image is not found.
        '''
        global programLogg

        try:
            self.img_pil = Image.open(self.img_path) # Must be declared as an attribute to avoid garbage collection
            self.image_resized = self.img_pil.resize((int(0.3*w_window_global), int(0.5*h_window_global)), Image.Resampling.LANCZOS)
            self.image = ImageTk.PhotoImage(self.image_resized) 

        except FileNotFoundError:
            programLogger.add_entry(f'[ERROR] Image file {self.img_path} not found.')
            self.image = None



    def save_settings(self):
        '''
        Saves the servos current limit settings to an external settings page. 
        Let's settings be saved.
        '''
        global SERVO_SETTINGS_PATH


        if os.path.exists(SERVO_SETTINGS_PATH):
            
            # If the settings-file already exists, load the curretn data.
            with open(SERVO_SETTINGS_PATH) as f:
                try:
                    settings = json.load(f)
                except json.JSONDecodeError:
                    settings = {}
        else:
            settings = {}

        # Add / modify the servos limit settings to/in the settings-data.
        settings[self.__name__] = {
            'min': self.min,
            'max': self.max,
            'mid': self.mid
        }

        # Save the new settings-data
        with open(SERVO_SETTINGS_PATH, 'w') as f:
            json.dump(settings, f, indent=4)

    
    def _load_settings(self):
        '''
        Loads any saved limit-data for the servo from the settings-file.
        '''

        global SERVO_SETTINGS_PATH

        # Check if file exists
        if not(os.path.exists(SERVO_SETTINGS_PATH)):
            return
        
        # Try loading the json-data
        try:
            with open(SERVO_SETTINGS_PATH, 'r') as f:
                settings = json.load(f)
        except json.JSONDecodeError:
            return  
        
        # If there is any data, save it to the object
        if self.__name__ in settings:
            servo_data = settings[self.__name__]
            self.min = servo_data.get('min', self.min)
            self.max = servo_data.get('max', self.max)
            self.mid = servo_data.get('mid', self.mid)




###################################################################################################       
################################ Camera Controller ########################################################
###################################################################################################

class CameraController(Picamera2):
    '''
    Handles the video-stream in the application and controls the camera.
    '''

    def __init__(self, resolution=(400,300)):

        super().__init__() 
        self.paused = True      # Determines if new frames are retrieved or not

        # Define preview size based on window size
        img_w = int(w_window_global * 0.8)
        img_h = int(h_window_global * 0.8)
        self.configure(self.create_preview_configuration(main={'size': (img_w, img_h)})) 
        self.start()

        time.sleep(1) # Give the camera time to start

        # Load haar cascade for face detection
        self.faceCascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")

        self.last_tracking = time.time() # Used to avoid detecting faces to often, because it slows doen the whole application


    def get_frame(self, force=False, tracking=False, resize_faktor=0.8, calibrating=False, point: Optional[Tuple[Optional[int], Optional[int]]] = None):
        '''
        Loads a new frame from camera if self.paused is not set or force is set to True.


        Args:
            force           (bool):                                             If set to True, captures a frame even if paused. Default is False.
            tracking        (bool):                                             Enables face tracking if set to True. Default is False.
            resize_faktor   (float):                                            Scaling factor for the output image. Default is 0.8.
            calibrating     (bool):                                             If set to 1, draws a calibration target at 'point'. Default is 0.
            point           (Optional[Tuple[Optional[int], Optional[int]]]):    The calibration point as (x, y).
                                                                                Use 'None' for one calibration coordinate to center it on that axis.

        '''
        global programLogger
        
        # If the camera is paused and update is not forced, don't load image
        if self.paused and not(force):
            return -1
        
        # Capture image
        frame = self.capture_array()
        if frame is None:
            programLogger.add_entry('[WARNING] Camera was not able to capture a frame.')
            return -1


        frame = cv2.cvtColor(frame, cv2.COLOR_RGBA2RGB) # Remove alpha channel, not used


        # Track if enough time has passed since last time and tracing is enabled
        now = time.time()
        if tracking and (now - self.last_tracking > 0.1):
            frame = self.find_face(frame)

        # Show calibration target if we're calibrating
        if calibrating and point is not None: # Point default to none when not used
            center = list(point)
            
            if point[0] is None and point[1] is None: 
                pass # Expects one value to be none, and one to be pixel value

            else:
                if point[0] is None: 
                    center[0] = int(frame.shape[1] // 2) # Place point at the middle horizontally

                if point[1] is None: 
                    center[1] = int(frame.shape[0] // 2)  # Place point at the middle vertivally

                # Draw target point
                center = tuple(center)
                cv2.circle(frame, center, 12, (255,0,0), -1) # Tegn target punkt

        # Resize image
        w = int(frame.shape[1] * resize_faktor)
        h = int(frame.shape[0] * resize_faktor)
        self.pil_img = Image.fromarray(frame).resize((w, h), Image.Resampling.LANCZOS)

        return ImageTk.PhotoImage(self.pil_img)
    

    def find_face(self, img):
        '''
        Looks for faces in a given image. Draws boxes around all detected faces and a dot in the middle one, that will be tracked.
        Calls the tracking function with the center point of the largest face detected.

        Returns the annotated image.
        '''
        global servoDriver,EYE_SERVO_H, EYE_SERVO_V
        
        # Make a copy of the given image and convert it to gray-scale
        face_img = img.copy()
        grey_img = cv2.cvtColor(img.copy(), cv2.COLOR_RGB2GRAY)
    
        # Detect the faces using the haar-cascade
        face_rects = np.array(self.faceCascade.detectMultiScale(grey_img)) #TODO: Close eyelids when no face is detected


        size = 0            # These variables are used to find the largest rectangle
        max_rect_data = 0   # These variables are used to find the largest rectangle

        # Draw rectangles around all detected faces and determine which is the largest one
        if face_rects.size != 0:

            for i, (x,y,w,h) in enumerate(face_rects):

                # Draw rectangle
                cv2.rectangle(face_img, (x,y), (x+w, y+h), (255,0,0), 5)

                # Find largest rectangle
                if w*h > size:
                    size = w*h
                    max_rect_data = (x, y, w, h)


            ########### Point servos towards the largest rectangle ###########

            # Parameters
            x,y,w,h = max_rect_data
            center_x = round(x+w/2)
            center_y = round(y+h/2)
            circle_r = 6
            circle_color = (255, 0, 0)
            circle_thickness = -1 # Fill circle, makes a dot
            
            # Draw circle at centre to mark target
            cv2.circle(face_img, (center_x, center_y), circle_r, circle_color, circle_thickness) # Tegn target punkt

            # Track point
            img_w = face_img.shape[1]
            img_h = face_img.shape[0]
            servoDriver.track_point(center_x, center_y, img_w, img_h)

        return face_img




###################################################################################################
###################################################################################################
###################################################################################################       
################################ GUI #############################################################
###################################################################################################
###################################################################################################
###################################################################################################



###################################################################################################       
################################ State Button ########################################################
###################################################################################################


class StateButton(ttk.Button):
    '''
    A button that changes between an off-state and on-state each time it's pressed,
    and changes appearance accordingly. Parent: ttk.Button
    '''
    def __init__(self, master=None, text='', usr_command=None, **kwargs):
        
        super().__init__(master, text=text, command=self.on_click, **kwargs)
        self['style'] = 'Home.TButton'
        
        self.usr_command = usr_command
        self.state = 0
        
    
    def on_click(self):
        
        # Change button appearace
        self.state = not(self.state)
        
        if self.state:
            self['style'] = 'Green.TButton'
        else:
            self['style'] = 'Home.TButton'

        if self.usr_command != None:
            self.usr_command(self.state)


###################################################################################################       
################################ Arrow Button ########################################################
###################################################################################################

class ArrowButton(ttk.Button):
    '''
    A button that can be used to steer the eyes manually towards one direction.
    '''
    
    def __init__(self, master=None, usr_command=None, direction: Literal['n', 's', 'e', 'w'] = 'u', **kwargs):
        global servoDriver

        self.direction = direction.lower() # Set letters to lower case to avoid case-sensitivity
        #### Determine direction ####
        match self.direction:
            case 'n':
                txt = '↑'
                self.servo = servoDriver.servos[EYE_SERVO_V]
                self.output = 1 # Set direction, top of img is zero
            case 's':
                txt = '↓'
                self.servo = servoDriver.servos[EYE_SERVO_V]
                self.output = -1 # Set direction, top of img is zero
            case 'w':
                txt = '←'
                self.servo = servoDriver.servos[EYE_SERVO_H]
                self.output = 1 # Set direction, left of img is zero
            case 'e':
                txt = '→'
                self.servo = servoDriver.servos[EYE_SERVO_H]
                self.output = -1 # Set direction, left of img is zero
            
        # Initialize parent button class
        super().__init__(master, text=txt, style="Arrow.TButton", **kwargs) 

        self.bind("<ButtonPress-1>", self._button_down) # Rising edge on button (pressed down)
        self.bind("<ButtonRelease-1>", self._button_up) # Falling edge on button (released)

        # TODO: Continous movement when held down


    def _button_down(self, event):
        '''
        Moves the servo one step in the determined direction.
        Changes the button style to the pressed-style.
        '''

        global ServoDriver   

        # Change style
        self.config(style='AccentArrow.Accent.TButton')

        # Move
        angle = self.servo.current_angle + self.output
        servoDriver.send_angle(self.servo.__name__, angle)


    def _button_up(self, event):
        '''
        Changes the style of the button back to the unpressed state.
        '''

        self.config(style='Arrow.TButton')




###################################################################################################       
################################ App ########################################################
################################################################################################### 


class App(tk.Tk):
    '''
    The main class that runs the program
    '''
    
    def __init__(self, avr_sender: AvrDriver):

        global h_window_global, w_window_global
        
        # Lag display-boks
        super().__init__()
        self.title('Eye Tracker')
        self.iconphoto(False, tk.PhotoImage(file='grafikk/icon.png'))
        self.option_add("*tearOff", False)

        # Configure exit
        self.bind('<Escape>', lambda e: self.on_close())
        
        # Sizing
        self.attributes('-fullscreen', True)
        self.update_idletasks()
        self.update()

        w_window_global = self.winfo_width()
        h_window_global = self.winfo_height()
  
        # Intialize camera
        self.videoController = CameraController()
        self.avrSender = avr_sender

        #TODO: Make an x to close button
        
        # Load and apply custom theme
        ttk.Style().theme_use('clam')

        ###### Custom styling ##########
        self.style = ttk.Style()
        font_used = self.style.lookup('TButton', 'font')

        menu_font = tkfont.Font(family='TkDefaultFont', size=28) 
        self.option_add('*Menu.font', menu_font)

        self.style.configure('Arrow.TButton', font=('TkDefaultFont', 36, 'bold'))
        self.style.configure('AccentArrow.Accent.TButton', font=('TkDefaultFont', 36, 'bold'))
        self.style.configure('Home.TButton', font=('TkDefaultFont', 32))
        self.style.configure('Servo.TButton', font=('TkDefaultFont', 22))
        self.style.configure('Home.Accent.TButton', font=('TkDefaultFont', 32))
        self.style.configure('LargeOptionMenu.TMenubutton', font=tkfont.Font(family='TkDefaultFont', size=16))

        # Red button, only works in clam. Made with GPT: https://chatgpt.com/share/683b26c3-77f4-8009-b601-c66b92ecccf9
        self.style.configure('Red.TButton', foreground='white', font=('TkDefaultFont', 32, 'bold')) 
        self.style.map('Red.TButton',
            background=[
                ('pressed', '#c1442c'),
                ('active', '#d65a3b'),
                ('!disabled', '#e76f51')  # normal state
                ]
        )
        
        # Yellow button style (pleasant gold), only works in clam. Made with GPT: https://chatgpt.com/share/683b26c3-77f4-8009-b601-c66b92ecccf9
        self.style.configure('Yellow.TButton', foreground='black', font=('TkDefaultFont', 32, 'bold'))
        self.style.map('Yellow.TButton',
            background=[
                ('pressed', '#d17e28'),
                ('active', '#e89641'),
                ('!disabled', '#f4a261')  # normal state
                ]
        )

        # Green button style (pleasant, consistent with yellow and red) Made with GPT: https://chatgpt.com/share/683b26c3-77f4-8009-b601-c66b92ecccf9
        self.style.configure('Green.TButton', foreground='white', font=('TkDefaultFont', 32))
        self.style.map('Green.TButton',
            background=[
                ('pressed', '#2b9348'),   # darker green when pressed
                ('active', '#55a630'),    # brighter green on hover
                ('!disabled', '#80b918')  # normal state
            ]
        )



        # Run the app
        self.current_frame = '' # Holds the current page when the app has been built
        self.bygg_gui()
        
    def bygg_gui(self):

        # Make a menu-bar
        self.menubar = tk.Menu(self)
        
        filemenu = tk.Menu(self.menubar, tearoff=0)
        # USe the filemenu to switch between pages
        filemenu.add_command(label='Home',                  command=lambda: self.show_frame(HomePage))
        filemenu.add_command(label='Servo Kalibrering',     command=lambda: self.show_frame(ServoPage))
        filemenu.add_command(label='Tracking Kalibrering',  command=lambda: self.show_frame(TrackingPage))
        filemenu.add_command(label='Settings',              command=lambda: self.show_frame(SettingsPage))
        self.menubar.add_cascade(label='☰', menu=filemenu)
        self.menubar.add_cascade(label='Home')

        
        self.config(menu=self.menubar)
        

        ## Build frame-structure (https://www.geeksforgeeks.org/tkinter-application-to-switch-between-different-page-frames/)
        
        # Create container
        container = ttk.Frame(self)  
        container.pack(side = 'top', fill = 'both', expand = True) 
        container.grid_rowconfigure(0, weight = 1)
        container.grid_columnconfigure(0, weight = 1)
  
        # initializing frames to an empty array
        self.frames = {}  
  
        # Loading the different page layouts
        for F in (HomePage, ServoPage, TrackingPage, SettingsPage):
  
            frame = F(container, self)
            self.frames[F] = frame 
            frame.grid(row = 0, column = 0, sticky ="nsew")
  

        # Start the program in the home screen and start serial-communication with the AVR
        self.show_frame(HomePage)   
        self.after(500, self.avrSender.start)
        
        
    def show_frame(self, cont):
        '''
        Load the page that has been requested from the menu-bar
        '''

        # Load the frame containing the page
        frame = self.frames[cont] 
        self.current_frame = frame.navn

        # Display the name of the new page in the menu-bar
        page_title_index = 1
        self.menubar.entryconfig(page_title_index, label=frame.navn)

        # Coordinate videController status between teh tracking and home page
        # This lets's the video remain on/off when the user switches between pages
        if frame.navn == 'Home':
            
            if frame.btn_kamera.state == self.videoController.paused: 
                frame.btn_kamera.on_click() 

        if frame.navn == 'Tracking Kalibrering':

            if frame.btn_camera.state == self.videoController.paused: 
                frame.btn_camera.on_click() 


        # DIsplay the page
        frame.tkraise()

    def on_close(self):
        '''
        Save tracking data when the program is closed, and close cleanly.
        '''
        global CALIBRATION_CSV_PATH

        df = self.frames[TrackingPage].calibration_df

        if df is not None:
            with open(CALIBRATION_CSV_PATH, 'w') as f:
                df.to_csv(f, index=False)

        self.destroy()

    

###################################################################################################       
################################ Home Page ########################################################
################################################################################################### 


class HomePage(ttk.Frame): 
    
    def __init__(self, parent_frame, app):
        
        super().__init__(parent_frame)
        self.navn = 'Home'
        self.App = app # The app class Home page belongs to
        
        # Create a home frame inside the parent frame for increased control, let's me choose the placement manager
        frm_home = ttk.Frame(self)
        frm_home.place(anchor='c', relx=0.5, rely=0.5)

        # Video Holder
        self.lbl_video = tk.Label(frm_home)
        self.lbl_video.grid(row = 0, column = 0, rowspan=3, padx = (25,50), pady = (20,10), sticky='nsew') 

        # Buttons
        self.btn_kamera =   StateButton( frm_home, text='Camera',        style='Home.TButton', usr_command=self.action_btn_camera) 
        self.btn_web =      StateButton( frm_home, text='Web Stream',    style='Home.TButton')
        self.btn_tracking = StateButton( frm_home, text='Tracking',      style='Home.TButton')

        # Dropdown  menu where the user can choose the tracking mode
        tracking_modes = TRACKING_MODES # Get the names of all the tracking modes available
        default_mode = tracking_modes[0]
        self.tracking_mode = tk.StringVar(value=default_mode)
        
        lst_tracking_mode = ttk.OptionMenu(
            frm_home,               # parent
            self.tracking_mode,     # variable
            default_mode,           # default value
            *tracking_modes,        # options
            command=self.on_select  # callback
            )
        lst_tracking_mode.configure(style='LargeOptionMenu.TMenubutton') # Styling

        # Place all the buttons and dropwdown menu in the frame
        self.btn_kamera.grid(   row=0, column=1, sticky='ew', padx=5, pady=0,   ipady=0, ipadx=10)
        self.btn_web.grid(      row=1, column=1, sticky='ew', padx=5, pady=(3,0),   ipady=2, ipadx=10)
        self.btn_tracking.grid( row=2, column=1, sticky='ew', padx=5, pady=(3,0),   ipady=2, ipadx=10)
        lst_tracking_mode.grid( row=3, column=1, sticky="ew", padx=5, pady=(3, 50), ipady=2, ipadx=10)
        

        self.lbl_video_image = None # Image holder for the video, not initialised 
        self.update_video(force=1) # TODO: Add placeholder before camera is turned on, now it just captures a frame


    def update_video(self, force=0):
        '''
        Loads a new frame to the video display.
        '''

        # Load new frame
        if self.App.current_frame == 'Home' or force:
            tk_image = self.App.videoController.get_frame(force=force, tracking=self.btn_tracking.state)
        else:
            tk_image = -1

        # Display the new frame if one was given
        if tk_image != (-1): 
            self.lbl_video_image = tk_image
            self.lbl_video.config(image=self.lbl_video_image)

        # Set fram-rate
        self.App.after(30, self.update_video)

    def action_btn_camera(self, btn_state):
        '''
        Turn video on/off.
        '''

        self.App.videoController.paused = not(btn_state) #Btn_state is given by the StateButton type object

    def on_select(self, tracking_mode):
        '''
        Switch tracking_mode
        '''
        global servoDriver
        servoDriver.tracking_mode = tracking_mode


###################################################################################################       
################################ Servo Page ########################################################
################################################################################################### 
    
class ServoPage(ttk.Frame):
    '''
    Where the user can calibrate the sensor-
    '''
    
    def __init__(self, parent, controller):

        global servoDriver
        
        self.navn = "Servo Kalibrering"
        super().__init__(parent)

        # Load servo-images
        for _, servo in servoDriver.servos.items():
            servo.load_image()

        self.bygg_gui()
            

    def bygg_gui(self):

        global servoDriver

        ################ Left side ##################################
        frm_left = ttk.LabelFrame(self, text='Servo Select')

        # Drop-down menu servo-select
        servos = list(servoDriver.servos.keys()) #get servo names
        self.valgt_servo = tk.StringVar(value=servos[0])

        lst_servo = ttk.OptionMenu(
            frm_left,                   # parent
            self.valgt_servo,           # variable
            servos[0],                  # default value
            *servos,                    # options
            command=self.on_select      # callback
            ) 
        lst_servo.configure(style='LargeOptionMenu.TMenubutton')
        lst_servo.grid(row=0, column=0, padx=(7, 5), pady=(20, 20),  sticky='ew')

        # Current servo info
        self.lbl_eye_part = ttk.Label(frm_left, text='', font=('TkDefaultFont', 18, 'bold'))
        self.lbl_eye_img = tk.Label(frm_left)

        self.lbl_eye_img.grid(row=2, column=0, padx=5, pady=(10,15))
        self.lbl_eye_part.grid(row=1, column=0, padx=(15, 5), pady=(10,3),  sticky='ew')
        

        

        ################ Right side ########################################
        frm_right = ttk.Frame(self)
        frm_right.columnconfigure(0, weight=1)


        # Illustration of expected servo position.
        frm_position = ttk.Frame(frm_right)
        frm_position.grid(row=0, column=0)

        self.lbl_protractor = tk.Label(frm_position, image=None)
        self.lbl_protractor.grid(row = 1, column = 0, padx = (0,10), pady = (25,40) )

        self.last_update = time.time()
        self.rotate_servo_img(0, force=1)


        # Frame containing signal slider that let's the user select the angle that should be sent to the servo
        frm_signal = ttk.Frame(frm_right)
        #frm_signal.columnconfigure(0, weight=1)
        frm_signal.columnconfigure(1, weight=1)
        frm_signal.columnconfigure(2, weight=1)
        frm_signal.columnconfigure(3, weight=1)
        frm_signal.grid(row=1, column=0, sticky='ew')

        lbl_signal = ttk.Label(frm_signal, text=f'Signal:', font=('TkDefaultFont', 16, 'bold'))
        lbl_signal.grid(row=0, column=0, padx=(15,5), pady=(15, 10), sticky='nsw')
        
        # Scale 
        self.scale = ttk.Scale(frm_signal, from_=-90, to=90, command = lambda val: self.on_scale_change(val)) # Start in the middle
        self.scale.grid(row=0, column=1, columnspan=3, padx=(10, 0), pady=15, sticky='ew')

        # Label showing scale value
        self.lbl_val = ttk.Label(frm_signal, text='0', foreground='grey', width=3, font=('TkDefaultFont', 16))
        self.lbl_val.grid(row=0, column=4, sticky='e', padx=(10, 60))

        self.on_select(self.valgt_servo.get())  
    
        self.scl_value = 0

        # Buttons (max, min, mid, send)
        frm_buttons = ttk.Frame(frm_right)
        frm_buttons.grid(row=3, column=0, pady=(30,0))

        btn_max =        ttk.Button(frm_buttons, text='Current ∠ = max', style='Servo.TButton', command=self.btn_max)
        btn_mid =        ttk.Button(frm_buttons, text='Current ∠ = mid', style='Servo.TButton', command=self.btn_mid)
        btn_min =        ttk.Button(frm_buttons, text='Current ∠ = min', style='Servo.TButton', command=self.btn_min)
        btn_send_angle = ttk.Button(frm_buttons, text='Send ∠',          style='Servo.TButton', command=self.btn_send)

        btn_max.grid(       row=1, column=0, padx=40, pady=5, sticky='nsew')
        btn_mid.grid(       row=0, column=1, padx=40, pady=(5,20), sticky='nsew')
        btn_min.grid(       row=1, column=1, padx=40, pady=5, sticky='nsew')
        btn_send_angle.grid(row=0, column=0, padx=40, pady=(5,20), sticky='nsew')


        ##################### Place parts on screen #########################
        frm_left.grid(row=0, column=0, sticky='w', padx=(45,0), pady=(20,15))
        frm_right.grid(row=0, column=1, sticky='sew', padx=(25, 10), pady=(15,15))
        self.columnconfigure(1, weight=1) 


    def on_select(self, servo_name):
        '''
        Performed when a new sensor is picked from the drop-down menu.
        Updates frame with new servo-illustration, and data.
        '''
        global servoDriver

        self.current_servo = servoDriver.servos[servo_name]
        self.scale.set(self.current_servo.current_angle - 90) # Move scale to servo position: [0-180] -> [-90, 90]

        self.lbl_eye_part.config(text=self.current_servo.__name__.capitalize())
        self.lbl_eye_img.config(image=self.current_servo.image)

    def on_scale_change(self, value):
        '''
        Performed when the scale slider is moved.
        Saves the new scale_value and moves the rotating servo illustration to reflect where the servo should be
        given the current settings of the selected servo.
        '''
        
        # Retrieve new value
        rounded_val = int(float(value))
        self.value =  rounded_val + 90 # Shift slider scale [-90, 90] to servo scale [0, 180]
        self.lbl_val.config(text=str(rounded_val)) # Illustration matches slider [-90, 90]

        # Rotate servo illustration
        # Assume slider value is on the adjusted servo scale and convert to [-90, 90], which is used to rotate servo image
        # slider value ∈ [servo.min, servi.max] ∈ [0, 180] -> [-90, 90]
        self.img_angle = self.current_servo.servoscale2scale(self.value, new_min=-90, new_max=90)
        self.rotate_servo_img(self.img_angle)

    def rotate_servo_img(self, deg: int, force=False):
        '''
        Rotates the head of teh servo in the servo-illustration to the angle given by deg.

        Args:
            deg (int):      Amount to rotate servo-head. -90 to 90' moves teh illustration from pointing left to pointing right.
            force (bool):   Force teh image rotation eventough the cool-down period has not passed since the last update
        '''

        # If enough time has passed since the last update (avoid overloading the program)
        cool_down_time = 0.05
        if time.time() - self.last_update < cool_down_time and not(force):
            return

        # Load background image and teh servo-head illustration.
        image = Image.open("grafikk/servo_bg.png") #TODO: Avoid loading these image on each run
        fg = Image.open("grafikk/servo_fg.png") # 'servo-head' image that is rotated

        image = image.copy()

        # Rotate servo
        fg = fg.rotate(deg*(-1), expand=True) 

        # Determine where the servo should be placed
        c_w = 356
        c_h = 327
        x = int(c_w - fg.size[0]/2)
        y = int(c_h - fg.size[1]/2)-10

        # Paste rotatet servo-head on the background
        image.paste(fg, (x,y), mask=fg)
        faktor = 0.75
        image = image.resize( (int(image.size[0] * faktor), int(image.size[1] * faktor)), Image.Resampling.LANCZOS)

        # Update servo-illustration
        self.img_servo_angle = ImageTk.PhotoImage(image) 
        self.lbl_protractor.config(image = self.img_servo_angle)

    def btn_send(self):
        '''
        Sends the last recorded  scale_value [-90, 90] (already right shifted to [0, 180]), and sends
        the angle to the AVR -> pca -> servo.
        '''

        global servoDriver
        servo_name = self.valgt_servo.get()
        servoDriver.send_angle(servo_name, self.value)
        servoDriver.servos[servo_name].current_angle = self.value

    def btn_mid(self):
        '''
        Saves the last recorded  scale_value [-90, 90] (already right shifted to [0, 180]), as the mid-point of the current
        servo. 
        The value is saved to the current servo Object, and written to the servo-settings file.
        Records the update in the logg.
        '''

        global servoDriver
        global programLogg  
    
        servo = servoDriver.servos[self.valgt_servo.get()]
        servo.mid = self.value
        servo.save_settings()
        programLogg.add_entry(f'Set mid value of {servo.__name__} to {servo.mid}')

    def btn_max(self):
        '''
        Saves the last recorded  scale_value [-90, 90] (already right shifted to [0, 180]), as the max-point of the current
        servo. 
        The value is saved to the current servo Object, and written to the servo-settings file.
        Records the update in the logg.
        '''

        global servoDriver
        global programLogg


        servo = servoDriver.servos[self.valgt_servo.get()]
        servo.max = self.value
        servo.save_settings()
        programLogg.add_entry(f'Set max value of {servo.__name__} to {servo.max}')

    def btn_min(self):
        '''
        Saves the last recorded  scale_value [-90, 90] (already right shifted to [0, 180]), as the min-point of the current
        servo. 
        The value is saved to the current servo Object, and written to the servo-settings file.
        Records the update in the logg.
        '''
        
        global servoDriver
        global programLogg

        servo = servoDriver.servos[self.valgt_servo.get()]
        servo.min = self.value
        servo.save_settings()
        programLogg.add_entry(f'Set min value of {servo.__name__} to {servo.min}')


 
  
###################################################################################################       
################################ Tracking Page ########################################################
################################################################################################### 
  
    
class TrackingPage(ttk.Frame):
    '''
    Where the user can calibrate the tracking.
    '''
    
    def __init__(self, parent, controller):
        global CALIBRATION_CSV_PATH, programLogg, CALIBRATION_HEADERS
        
        self.navn = 'Tracking Kalibrering'
        self.controller = controller
        super().__init__(parent) 

        ####### Check and validate calibration data file #########
        self.calibration_df = None
        self.calibration_index = 0
        try:
            df = pd.read_csv(CALIBRATION_CSV_PATH)
            required_headers = CALIBRATION_HEADERS 

            # Check that the column headers are correct
            if required_headers != list(df.columns):
                programLogg.add_entry(f'[WARNING] Calibration csv has the wrong format. Expected: {required_headers}')

            # Check that all values in the axis column are either 'x' or 'y'
            elif not( df['axis'].isin(['x', 'y']).all()):
                programLogg.add_entry(f'[WARNING] Calibration csv has invalid values in axis column. Expected "x" or "y".')

            # Check that all values in the px column are numeric
            elif not( pd.to_numeric(df['px'], errors='coerce').notna().all()):
                programLogg.add_entry(f'[WARNING] Calibration csv has invalid values in px column. Column must contain only numbers.')

            # Check that all values in the angle column are numeric or NaN
            elif not( df['angle'].apply(lambda x: pd.isna(x) or isinstance(x, (int, float, np.integer, np.floating))).all()):
                programLogg.add_entry(f'[WARNING] Calibration csv has invalid values in angle column. Column must contain only numbers or NaN.')

            # Check if there is data
            elif df.empty:
                programLogg.add_entry(f'[WARNING] Calibration csv is empty.')

            # All checks ok, load data
            else:
                self.calibration_df = df 

        except FileNotFoundError as e:
            programLogg.add_entry(f'[INFO] No calibration csv file available. Expected: {CALIBRATION_CSV_PATH}')

        except pd.errors.EmptyDataError:
            programLogg.add_entry(f'[WARNING] Calibration csv empty or corrupt')

        

         ####### Bygg gui #########
        self.bygg_gui()

    def bygg_gui(self):

        #Videoholder
        self.lbl_video = tk.Label(self)
        self.lbl_video.grid(row = 0, column = 0, padx = 50, pady = 50, sticky='nsew') 

        ##### Right Side #####
        frm_right = ttk.Frame(self)
        frm_right.grid(row=0, column=1)

        # Arrow buttons
        pad = 20
        w = 3
        btn_up =    ArrowButton(frm_right, direction='n', width=w, padding=(0, pad))
        btn_down =  ArrowButton(frm_right, direction='s', width=w, padding=(0, pad))
        btn_left =  ArrowButton(frm_right, direction='w', width=w, padding=(0, pad))
        btn_right = ArrowButton(frm_right, direction='e', width=w, padding=(0, pad))

        btn_up.grid(    row=0, column=1)
        btn_down.grid(  row=2, column=1)
        btn_left.grid(  row=1, column=0, padx=(100, 0))
        btn_right.grid( row=1, column=2)
        
        #### Bottom buttonbar ####
        frm_buttons = ttk.Frame(self)
        frm_buttons.grid(row=1, column=0, columnspan=2, pady=25, padx=(100, 0))

        # Control buttons (skip calibration point, restart from first calibration point, register angle at calibration point, toggle camera on/off)
        w = 10
        self.btn_skip =     ttk.Button( frm_buttons,    text='Skip',    width=w, style='Red.TButton',       command=self.skip_action)
        self.btn_hit =      ttk.Button( frm_buttons,    text='Hit',     width=w, style='Green.TButton',     command=self.hit_action)
        self.btn_restart =  ttk.Button( frm_buttons,    text='Restart', width=w, style='Yellow.TButton',    command=self.restart_action) 
        self.btn_camera =   StateButton(frm_buttons,    text='Camera',  width=w,                            usr_command=self.camera_btn_action)


        self.lbl_status = ttk.Label(frm_buttons, text='Indeks:', foreground='black', font=("TkDefaultFont", 30, "bold"), anchor="center")

        # If there is a valid calibration file: display how many points are calibrated
        if self.calibration_df is not None:
            self.lbl_progress = ttk.Label(frm_buttons, text=f'', foreground='black', font=("TkDefaultFont", 30, "bold"), anchor="center") # Text set in update function
            self.update_status_labels()

        # If there is no valid calibration file: display error
        else:
            self.lbl_progress = ttk.Label(frm_buttons, text='Error', foreground='red', font=("TkDefaultFont", 30, "bold"), anchor="center")
        
        # Place buttons
        spacing_i = 30
        spacing_o = 50
        padding = 25
        self.btn_skip.grid(         row=0, column=0, padx=spacing_i,                                   sticky='ew')
        self.btn_hit.grid(          row=0, column=1, padx=(spacing_o,spacing_i),                       sticky='ew')
        self.btn_restart.grid(      row=1, column=0, padx=spacing_i,              pady=(padding,0),    sticky='ew')
        self.btn_camera.grid(       row=1, column=1, padx=(spacing_o,spacing_i),  pady=(padding,0),    sticky='ew')
        self.lbl_status.grid(       row=0, column=2, padx=(40, 10),                                    sticky='ew')
        self.lbl_progress.grid(     row=1, column=2, padx=(40, 10),               pady=(padding,0),    sticky='ew')
        
        # Fill the video holder with a frame
        self.update_video(force=1) # TODO: Add placeholder before camera is turned on


    def count_calibrated(self):
        '''
        If the loaded calibration file was valid, this function counts how many
        calibration points that have been given a corresponding angle and how many 
        calibration points there are in total.

        If all points have been calibrated it informs the servoDriver that the calibration
        is ready.

        Returns no_calibrated_points, no_points
        '''
        global servoDriver
        
        if self.calibration_df is None: return

        # Count number of calibration points, and how many that have been calibrated
        points = self.calibration_df.shape[0]
        calibrated = points - self.calibration_df['angle'].isna().sum()

        # If all points have been calibrated, inform the servoDriver
        if points == calibrated: servoDriver.calibration_ready = True

        return calibrated, points
    
    def is_current_calibrated(self):
        '''
        Checks if the current calibration-point ( the one being shown in the camera feed )
        already has been mapped to an angle.

        Returns
            - None,     if there is no calirbation_df
            - False     if the point has not been assigned an angle
            - True      if the point has been assigned an angle
        '''

        if self.calibration_df is None: return

        if pd.isna(self.calibration_df['angle'].loc[self.calibration_index]): return False

        return True


    def update_status_labels(self):
        '''
        Updates the status label in the gui with the number of calibrated points, and the total number of points.
        Colors the text red if the current point has not been calibrated.
        Colors the text green if the current point has been calibrated.
        '''

        if self.calibration_df is None: return

        # Count total number of points, and number of calibrated points
        self.calibrated, self.points = self.count_calibrated()

        # Give the text the right colour 
        if self.is_current_calibrated():    
            self.lbl_status.config(foreground='green')
        else:                               
            self.lbl_status.config(foreground='red')      
        
        # Update text-fields
        self.lbl_status.config(text=f'Indeks: {self.calibration_index}')
        self.lbl_progress.config(text=f'{self.calibrated} / {self.points}')



    def update_video(self, force=0):
        '''
        Retrieve a frame for the video if there is a valid calibration file.
        '''

        point, calibrating = None, False
        if self.calibration_df is not None:

            # Get the data for the current calibration point
            row = self.calibration_df.iloc[self.calibration_index]

            # Retrieve the pixel count for the axis, and make a point tuple (x, y)
            if row['axis'] == 'x':      point = (int(round(row['px'])), None)
            if row['axis'] == 'y':      point = (None, int(round(row['px'])))
            
            point = tuple(point)

            calibrating = True

        if self.controller.current_frame == 'Tracking Kalibrering' or force:
            # Load the next video frame
            tk_image = self.controller.videoController.get_frame(force=force, 
                                                                 tracking=0, 
                                                                 resize_faktor=0.6,
                                                                 point=point,
                                                                 calibrating=calibrating)
        else:
            tk_image = -1

        # If a frame was loaded, display the new frame
        if tk_image != (-1): 
            self.lbl_video.image = tk_image
            self.lbl_video.config(image=self.lbl_video.image)

        # Set the refresh rate of the video. 
        self.controller.after(30, self.update_video)

    def camera_btn_action(self, state):
        '''
        Toggles the camera feed on/off.
        '''

        self.controller.videoController.paused = not(state)

    def skip_action(self):
        '''
        Skip the current calibration point and jump to the next one.
        '''

        self.calibration_index += 1

        # If at the end, go back to the first calibration point (index 0)
        if self.calibration_index >= self.calibration_df.shape[0]:
            self.calibration_index = 0

        self.update_status_labels()

    def restart_action(self):
        '''
        Jump back to the first calibration point at index 0.
        '''
        
        self.calibration_index = 0
        self.update_status_labels()

    def hit_action(self):
        '''
        Maps the current angle of the relevant servo to the the current calibration point
        and saves the calibration data.
        Performs the skip action (moves on to the next calibration point.)
        '''

        global programLogger, servoDriver
        
        # Get the data entry for the current calibration point.
        row = self.calibration_df.loc[self.calibration_index]

        # Find the right servo
        servo = None
        if      row['axis'] == 'x': servo = EYE_SERVO_H
        elif    row['axis'] == 'y': servo = EYE_SERVO_V


        if servo is None:
            programLogger.add_entry(f'[ERROR] Tracking calibration; invalid axis value at {self.calibration_index}')
            return
    
        # Get the current angle and save it
        angle = servoDriver.get_angle(servo_name=servo) 
        self.calibration_df.loc[self.calibration_index, 'angle'] = angle

        self.skip_action()




###################################################################################################       
################################ Settings Page ########################################################
################################################################################################### 


class SettingsPage(ttk.Frame):
    '''
    Page where the user can read the logg, and refresh it.
    Any settings-control is meant to be added here.
    '''
    
    def __init__(self, parent, app):
        
        self.navn = 'Settings'
        super().__init__(parent)

        self.bygg_gui()
        

    def bygg_gui(self):

        global h_window_global, w_window_global, programLogg

        # Treeview code based on example.py from the Forest-ttk-theme
        #https://github.com/rdbende/Forest-ttk-theme/blob/master/example.py
        #TODO: Newest settings first in treeview

        ########################## Log window #############################################
        # Panedwindow
        paned = ttk.PanedWindow(self)
        paned.grid(row=0, column=0, pady=(20, 5), padx=20, sticky="nsew")

        # Pane
        pane = ttk.Frame(paned)
        paned.add(pane, weight=1)

        # Create a Frame for the Treeview
        treeFrame = ttk.Frame(pane, width=w_window_global/2, height=int(h_window_global * 0.85))
        treeFrame.pack(expand=False, fill="both", padx=5, pady=5)
        treeFrame.pack_propagate(False) 

        # Scrollbar
        treeScrolly = ttk.Scrollbar(treeFrame)
        treeScrolly.pack(side="right", fill="y")
        treeScrollx = ttk.Scrollbar(treeFrame, orient="horizontal")
        treeScrollx.pack(side="bottom", fill="x")
        

        # Treeview
        cols = ('c1', 'c2', 'c3')

        self.treeview = ttk.Treeview(treeFrame, 
                                selectmode="extended", 
                                yscrollcommand=treeScrolly.set, 
                                xscrollcommand=treeScrollx.set,
                                columns=cols, 
                                show='headings',
                                height=12)
        self.treeview.pack(expand=True, fill="both")

        treeScrolly.config(command=self.treeview.yview)
        treeScrollx.config(command=self.treeview.xview)

        # Treeview columns
        self.treeview.column('c1', anchor="w", width=120, stretch=False)
        self.treeview.column('c2', anchor="w", width=120, stretch=False)
        self.treeview.column('c3', anchor="w", minwidth=300, stretch=True)

        # Treeview headings
        self.treeview.heading('c1', text='Index', anchor='w')
        self.treeview.heading('c2', text='Dato', anchor='w')
        self.treeview.heading('c3', text='Logg', anchor='w')

        # Fill the tree-view with any previously saved logg-data
        for entry in programLogg.load_all():
            self.add_logg_entry(id=entry[0], tid=entry[1], message=entry[2])


        ########################## Inputs #############################################

        # Initialize input frame
        frm_inputs = ttk.Frame(self, width=w_window_global/2)
        frm_inputs.grid(row=0, column=1, sticky='nsew', padx=(100, 0), pady=30)
        frm_inputs.grid_columnconfigure(0, weight=1)

        # Load Gear Image (https://www.flaticon.com/free-icon/settings_900834?term=settings)
        sidelen = int(w_window_global * 0.12)

        try:
            pil_img = Image.open('grafikk/settings.png').resize((sidelen, sidelen), Image.Resampling.LANCZOS)
            self.settings_img = ImageTk.PhotoImage(pil_img)
        except Exception as e:
            programLogg.add_entry(f'[ERROR] image "grafikk/settings.png" could not load.')
            gray_img = Image.new('RGB', (sidelen, sidelen), color='gray')
            self.settings_img = ImageTk.PhotoImage(gray_img)
        
        # Label that holds gear image
        test_label = tk.Label(frm_inputs, image=self.settings_img)
        test_label.grid(row = 0, column = 0, padx = (15,10), pady = (15, 30), sticky='n')
        

        # Buttons
        btn_test = ttk.Button(frm_inputs, text='Add entry', width=12, style='Home.TButton', command=self.add_logg_btn)
        btn_test.grid(row=1, column=0, sticky='ew')

        btn_reset = ttk.Button(frm_inputs, text='Reset logg', width=12, style='Home.TButton', command=self.reset_logg)
        btn_reset.grid(row=2, column=0, sticky='ew', pady=(30, 0))

        btn_refresh = ttk.Button(frm_inputs, text='Refresh logg', width=12, style='Home.TButton', command=self.refresh_logg)
        btn_refresh.grid(row=3, column=0, sticky='ew', pady=(30,0))


    def add_logg_entry(self, tid: str, message: str, id=None):
        '''
        Adds a logg entry to the treeview and logg file.
        The id prameter can be used to pick the position of the entry.
        '''

        # Give the entry an id
        if id == None:
            # If no id is given, calculate id from the number of entries in the treeview
            idx = len(self.treeview.get_children('')) + 1   
        else:
            idx = id


        # Add data entry to treeview  #TODO: Add the newest logg entries to the top of the treeview
        self.treeview.insert('', tk.END, values=(idx, tid, message))

        # Stop the treeview from expanding horizontally to make it scrollable
        font = tkfont.nametofont("TkDefaultFont")
        for col in self.treeview['columns']:
            texts = [self.treeview.heading(col, "text")] + [self.treeview.set(item, col) for item in self.treeview.get_children("")]
            max_px = max(font.measure(txt) for txt in texts)
            self.treeview.column(col, width=max_px + 50, stretch=False) 

    
    def refresh_logg(self):
        '''
        Reloads logg data from the logger into the treeview.
        '''
        global programLogg

        # Remove all treeview entries
        for entry in self.treeview.get_children():
            self.treeview.delete(entry)

        # Repopulate the treeview
        for entry in programLogg.load_all():
            self.add_logg_entry(id=entry[0], tid=entry[1], message=entry[2])


    def add_logg_btn(self):
        '''
        Adds a test-entry to the logg, to see if its's working.
        '''
        global programLogg
        programLogg.add_entry('[INFO] This is a manually added logg entry.')

    def reset_logg(self):
        '''
        Deletes the logg.
        '''
        global programLogg
        programLogg.reset()


# Intialize the drivers
programLogg = Logger()
avrComms = AvrDriver(baud=115200)
servo_info = [(EYE_SERVO_V,   'eye-vertical',     1), 
              (EYE_SERVO_H,   'eye-horisontal',   0), 
              ('Servo 3',   'eyelid-LD',        5), 
              ('Servo 4',   'eyelid-LU',        4), 
              ('Servo 5',   'eyelid-RD',        3), 
              ('Servo 6',   'eyelid-RU',        2)]

servos = {name: Servo(name, f'grafikk/{image}.png', channel) for name, image, channel in servo_info}
servoDriver = ServoDriver(servos)

# Start the app
root = App(avrComms)
programLogg.settings_page = root.frames[SettingsPage]

root.mainloop()

# Exit action
avrComms.stop()                 # Stop the background communication thread
root.videoController.close()    # Release the camera


##################### Plot tracking data ##################
#['servo', 'img_point', 'img_max', 'servo_angle', 'servo_min', 'servo_max'])
'''
if os.path.isfile(TRACKING_CSV_PATH):
    
    df = pd.read_csv(TRACKING_CSV_PATH)

    if 'servo' in df.columns:
        servo_groups = df.groupby('servo') 

        if len(servo_groups) != 2:
            print('Unexpected number of servogrups when trying to plot. Abort.')
        else:
            fig, axes = plt.subplots(1, 2, figsize=(12, 5))

            for ax, (name, group) in zip(axes, servo_groups):
                ax.plot(group['img_point'], group['servo_angle'], marker='.', linestyle='None')
                ax.set_title(f"Servo: {name}")
                ax.set_xlabel("Image point (px)")
                ax.set_ylabel("Servo angle (°)")
                ax.grid(True)
                ax.set_ylim(group['servo_min'].iloc[0], group['servo_max'].iloc[0]) #Should be the same value for all in group
                ax.set_xlim(0, group['img_max'].iloc[0])
            
            mplcursors.cursor(hover=True)
            plt.tight_layout()
            plt.show()
'''

# Midlertidig plotte funksjon
plt.figure()
plt.plot(theta_df['angle_v'].dropna(), theta_df['theta_v'].dropna(), marker='.', linestyle='None')
plt.title("Theta values - vertical")
plt.xlabel("Angle [degrees]")
plt.ylabel("Theta")
plt.grid(True)
plt.show()

plt.figure()
plt.plot(theta_df['angle_h'].dropna(), theta_df['theta_h'].dropna(), marker='.', linestyle='None')
plt.title("Theta values - horizontal")
plt.xlabel("Angle [degrees]")
plt.ylabel("Theta")
plt.grid(True)
plt.show()

