/*
 * board.c
 *
 * Created: 11.11.2024 17:07:47
 *  Author: Buzz Lightyear
 */ 


#include "board.h"




// Sets a pin on a given port as either input (''i or 'I') or Output ('o' or 'O'). Optionally enables inven.
void pin_mode(PORT_t *port, uint8_t pin, uint8_t mode, uint8_t inven, uint8_t pullup)
{
	
	if (mode == 'o' || mode == 'O')
	{
		port->DIRSET = (1 << pin);
	} 
	else 
	{
		port->DIRCLR = ( 1 << pin);
		
		if (pullup == 1)
		{
			pinxctrl_config(port, pin, PORT_PULLUPEN_bm);
		}
	}
	
	if (inven)
	{
		pinxctrl_config(port, pin, PORT_INVEN_bm | PORT_PULLUPEN_bm);
	}		
}

// Adds to the config of PORTX.pinxctrl for a given port and pin
void pinxctrl_config(PORT_t *port, uint8_t pin, uint8_t pinctrl_bm)
{
	// Example use: pinxctrl_config(&LEDPORT, pin, PORT_INVEN_bm);
	switch (pin)
		{
			case 0:
				port->PIN0CTRL |= pinctrl_bm;
				break;
			case 1:
				port->PIN1CTRL |= pinctrl_bm;
				break;
			case 2:
				port->PIN2CTRL |= pinctrl_bm;
				break;
			case 3:
				port->PIN3CTRL |= pinctrl_bm;
				break;
			case 4:
				port->PIN4CTRL |= pinctrl_bm;
				break;
			case 5:
				port->PIN5CTRL |= pinctrl_bm;
				break;
			case 6:
				port->PIN6CTRL |= pinctrl_bm;
				break;
			case 7:
				port->PIN7CTRL |= pinctrl_bm;
				break;
		}
}


// Resets the config of PORTX.pinxctrl for a given port and pin
void pinxctrl_reset(PORT_t *port, uint8_t pin)
{
	// Example use: pinxctrl_config(&LEDPORT, pin, PORT_INVEN_bm);
	switch (pin)
	{
		case 0:
		port->PIN0CTRL = 0;
		break;
		case 1:
		port->PIN1CTRL = 0;
		break;
		case 2:
		port->PIN2CTRL = 0;
		break;
		case 3:
		port->PIN3CTRL = 0;
		break;
		case 4:
		port->PIN4CTRL = 0;
		break;
		case 5:
		port->PIN5CTRL = 0;
		break;
		case 6:
		port->PIN6CTRL = 0;
		break;
		case 7:
		port->PIN7CTRL = 0;
		break;
	}
}


void pin_enable_interrupt(PORT_t *port, uint8_t pin, char edge)
{
	uint8_t ISR_config = 0;
	if (edge == 'b' || edge == 'B')
		ISR_config = PORT_ISC_BOTHEDGES_gc;
	else if (edge == 'R' || edge == 'r')
		ISR_config = PORT_ISC_RISING_gc;
	else if (edge == 'F' || edge == 'f')
		ISR_config = PORT_ISC_FALLING_gc;
	else if (edge == 'L' || edge == 'l')
		ISR_config = PORT_ISC_FALLING_gc;
	else 
	{
		ISR_config = PORT_ISC_INTDISABLE_gc;
		//printf("Invalid edge option. Interrupt disabled.\n");
	}
	
	pinxctrl_config(port, pin, ISR_config);
}


// Drives a pin on a given port to HIGH
void set_pin_high(PORT_t *port, uint8_t pin)
{
	port->OUTSET = (1 << pin);
}

// Drives a pin on a given port to LOW
void set_pin_low(PORT_t *port, uint8_t pin)
{
	// Example use: , set_pin_hlow(&LEDPORT, pinx_bp)
	port->OUTCLR = (1 << pin);
}



// Reads pin state of digital input pin
uint8_t digital_read(PORT_t *port, uint8_t pin)
{
	// Example of usage: digital_read(&BUTTONPORT, pin)
	uint8_t in_val = port->IN;
	return in_val & (1 << pin);
}


// #############################################################################################
// ###################### Utility Functions ####################################################
// #############################################################################################

void count_down(uint8_t seconds)
{
	for (int num = seconds; num >= 0; num--)
	{
		//printf("%i...\n", num);
		_delay_ms(1000);
	}
}


