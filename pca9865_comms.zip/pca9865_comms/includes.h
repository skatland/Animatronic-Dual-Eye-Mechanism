/*
 * includes.h
 *
 * Created: 20.11.2024 01:19:43
 *  Author: Buzz Lightyear
 */ 


#ifndef INCLUDES_H_
#define INCLUDES_H_

//#include "adc.h"
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/sleep.h>
#include <avr/wdt.h>
#include "board.h"
//#include "ccl.h"
#include "fcpu.h"
//#include "miscellaneous.h"
//#include "rtc.h"
#include <stdio.h>
#include <string.h>
#include "strings.h"
//#include "timer.h"
#include "usart.h"
#include <util/delay.h>




#endif /* INCLUDES_H_ */