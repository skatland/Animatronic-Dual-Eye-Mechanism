/*
 * avr.i2c.pca.c
 *
 * Created: 26.05.2025 16:10:46
 * Author : sigve
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/cpufunc.h>
#include "board.h"
#include "usart.h"
#include "fcpu.h"
#include <util/delay.h>
#include "i2c.h"
#include "pca9685.h"
#include <string.h>

uint8_t PCA_ADRESS = 0x40;

uint8_t x_offset = 90  ;  //horisontal
uint8_t y_offset = 90;  //vertikal



int main(void) {
	
	// init_main_clk_as_oschf_16M
	ccp_write_io((void *) &CLKCTRL.OSCHFCTRLA, CLKCTRL_FRQSEL_16M_gc | CLKCTRL_AUTOTUNE_bm | CLKCTRL_RUNSTBY_bm);
	while (!(CLKCTRL.MCLKSTATUS & CLKCTRL_OSCHFS_bm));
	ccp_write_io((void *) &CLKCTRL.MCLKCTRLA, CLKCTRL_CLKSEL_OSCHF_gc);
	while (CLKCTRL.MCLKSTATUS & CLKCTRL_SOSC_bm);
	
	// General set-up
	i2c_init();
	pca9685_init();
	
	USART1_init(115200);
	USART1_transmit_str("USART init OK.\n");
	
	
	// Visual indicator setup completed
	pin_mode(&PORTD, IO2_PIN_bp, 'O', 0, 1); // TX pin settings inven off, pull-up on
	set_pin_high(&IO_PORT, IO2_PIN_bp);
	
	pca9685_set_servo_angle(0x40, 0, 70);
	pca9685_set_servo_angle(0x40, 1, 70);
	
	
	sei();


	while (1) {
		
		//USART1_transmit_str("[A]");
		//PORTD.OUTSET = PIN2_bm;
		_delay_ms(300);
		//pca9685_set_servo_angle(0x40, 0, x_offset);
		
	}
}

int STR_RECEIVE_EN = 1;
char recieved_string[20]; // TODO: Samordne buffer size med receive string funksjon

ISR(USART1_RXC_vect)
{
	char c;
	c = USART1_receive_char();
	
	if( ( STR_RECEIVE_EN && (c == START_CHAR) ) )
	{ //Start receiving string if enabled and start char detected
		

		USART1_receive_str(recieved_string); // TODO: failsafe
		SplitStrStruct splitStr = split_string(recieved_string, ",");
		
		if (splitStr.length == 2)
		{
			// Expected string format [servo,angle]
			int32_t servo = str_to_int(splitStr.tokens[0], strlen(splitStr.tokens[0]));
			int32_t angle = str_to_int(splitStr.tokens[1], strlen(splitStr.tokens[1]));
			char infostr[40];
			sprintf(infostr, "Servo: %ld, Angle: %ld.\n", servo, angle);
			
			// servo and angle are in the right range, -1 is the error flag from str_to_int
			if ( servo > -1 && servo < 6 && angle > -1 && angle < 181 ) 
			{
				USART1_transmit_str("A\n"); // Send ACK
				
				USART1_transmit_str(infostr);
				
				pca9685_set_servo_angle(0x40, servo, angle);
			}
			else
			{
				USART1_transmit_str("N\n"); // Send NACK
			}
		}
		else
		{
			USART1_transmit_str("N\n"); // Send NACK
		}
		
		
		for (int i=0; i<splitStr.length; i++)
		{
			USART1_transmit_str(splitStr.tokens[i]);
			USART1_transmit_char('\n');
		}

			
	}
}





