/*
 * fcpu.h
 *
 * Created: 05.11.2024 13:04:12
 *  Author: Buzz Lightyear
 */ 


#ifndef FCPU_H_

#define FCPU_H_

//#define F_CPU 4000000UL
//#define F_CPU 32768UL
#define F_CPU 16000000UL


#endif /* FCPU_H_ */