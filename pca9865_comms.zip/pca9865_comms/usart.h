/*
 * USART.h
 *
 * Created: 08.09.2024 14:18:04
 *  Author: Buzz Lightyear
 */ 


#ifndef USART_H_

#define USART_H_


// Includes
#include <avr/io.h>
#include <avr/interrupt.h>
#include "board.h"
#include "fcpu.h"
#include <stdio.h>
#include <string.h>
#include <util/delay.h>


// Global variables
#define START_CHAR '['
#define STOP_CHAR ']'
extern int STR_RECEIVE_EN;


// Functions
void USART1_init (uint32_t baud_rate);

void USART1_transmit_char ( char c) ;
void USART1_transmit_str (char *str);

char USART1_receive_char () ;
void USART1_receive_str();


void USART1_test(uint16_t min, uint16_t max);



#endif /* USART_H_ */