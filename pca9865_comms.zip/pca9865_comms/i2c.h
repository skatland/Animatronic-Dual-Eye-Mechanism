/*
 * i2c.h
 *
 * Created: 26.05.2025 16:11:49
 *  Author: sigve
 */ 


#ifndef I2C_H_
#define I2C_H_
#include <stdint.h>

void i2c_init(void);
uint8_t i2c_start(uint8_t address);
uint8_t i2c_write(uint8_t data);
void i2c_stop(void);

#endif

