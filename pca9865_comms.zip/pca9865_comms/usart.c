/*
 * USART.c
 *
 * Created: 08.09.2024 14:17:45
 *  Author: Buzz Lightyear
 */ 

#include "USART.h"




void USART1_init (uint32_t baud_rate)
{
	// BASIC FUNCTION SETUP
	
	uint32_t baud = 64 * (uint32_t)F_CPU / (16*(baud_rate));
	USART1.BAUD = (uint16_t) baud;
	//USART3.BAUD = 1666; // Manually set baud-setting for 9600 @4MHz
	
	USART1.CTRLC = USART_CHSIZE_8BIT_gc; // Asynch mode, no parity, 1 stop bit, 8 data bits

	pin_mode(&USART1PORT, USART1_TXD_PIN_bp, 'O', 0, 1);
	pin_mode(&USART1PORT, USART1_RXD_PIN_bp, 'i', 0, 0);

	USART1.CTRLB = USART_RXEN_bm | USART_TXEN_bm;
	

	USART1.CTRLA = (1 << USART_RXCIE_bp); // RX-interrupt enable
}



void USART1_transmit_char (char c)
{
	while( !(USART1.STATUS & USART_DREIF_bm) )
	{
		;
	}
	
	USART1.TXDATAL = c;
}

void USART1_transmit_str (char* str)
{
	int len = strlen(str);

	for (int i=0; i<len; i++)
	{
		USART1_transmit_char(str[i]);
	}
}

char USART1_receive_char ()
{
	while (!(USART1.STATUS & USART_RXCIF_bm))
	{
		_delay_ms(200);
		break;
	}
		
	return USART1.RXDATAL;
}

void USART1_receive_str (char* str_out)
{ 
	int buffersize = 20;
	char character; 
	char buffer[buffersize]; 
	int ind = 0; 

	character = USART1_receive_char();
	
	// RECIEVE CHARACTERS UNTIL YOU SEE THE STOP CHARACTER	
	while ((character != STOP_CHAR) && (ind < buffersize-1))
	{
		buffer[ind] = character;
		ind++;
		character = USART1_receive_char();
		//printf("Steg 1.1: %i < %i    %c != %c\n", ind, buffersize-1, character, STOP_CHAR);
	}
	
	buffer[ind] = '\0'; // Terminate str.
	
	strcpy(str_out, buffer);
}




void USART1_test(uint16_t min, uint16_t max)
{
	uint16_t old_baud = USART1.BAUD;
	
	for (int i=min; i<=max; i++)
	{
		USART1.BAUD = i;
		_delay_ms(50);
		printf("\nBAUD: %d!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n", i);
	}
	
	printf("Old baud: %u", old_baud);
}