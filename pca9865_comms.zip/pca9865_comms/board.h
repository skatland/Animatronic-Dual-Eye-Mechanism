/*
 * board.h
 *
 * Created: 11.11.2024 16:25:10
 *  Author: Buzz Lightyear
 */ 


#ifndef BOARD_H_
#define BOARD_H_

#include <avr/io.h>
#include "includes.h"
#include <avr/io.h>
#include "fcpu.h"

#define USART1PORT				PORTC
#define IO_PORT					PORTD
#define I2CPORT					PORTA


#define IOPORT_vect			PORTD_PORT_vect

#define ANALOG1_PIN_bp			PIN1_bp
#define ANALOG4_PIN_bp			PIN4_bp

#define IO2_PIN_bp				PIN2_bp
#define IO3_PIN_bp				PIN3_bp

#define SDA_PIN_bp				PIN2_bp
#define SCL_PIN_bp				PIN3_bp



#define USART1_TXD_PIN_bp		PIN0_bp
#define USART1_RXD_PIN_bp		PIN1_bp



//Slette?
#define ADC_MUXPOS_1_gc		ADC_MUXPOS_AIN4_gc
#define ADC_MUXPOS_2_gc		ADC_MUXPOS_AIN7_gc 
#define ADC_MUXPOS_LIGHT_gc			ADC_MUXPOS_AIN3_gc 
#define ADC_MUXPOS_TMP235_gc		ADC_MUXPOS_AIN5_gc
#define TCA_PORTMUX_BUZZER_gc		PORTMUX_TCA0_PORTF_gc
#define TCA_PORTMUX_SERVO_gc		PORTMUX_TCA0_PORTE_gc
#define TCA_PORTMUX_LEDS_gc			PORTMUX_TCA0_PORTC_gc

#define TCA_SPLIT_WO_LED0_EN		TCA_SPLIT_LCMP0EN_bm
#define TCA_SPLIT_WO_LED1_EN		TCA_SPLIT_LCMP1EN_bm
#define TCA_SPLIT_WO_LED2_EN		TCA_SPLIT_LCMP2EN_bm
#define TCA_SPLIT_WO_LED3_EN		TCA_SPLIT_HCMP0EN_bm

#define TCA_SPLIT_CMP_LED0			TCA0.SPLIT.LCMP0
#define TCA_SPLIT_CMP_LED1			TCA0.SPLIT.LCMP1
#define TCA_SPLIT_CMP_LED2			TCA0.SPLIT.LCMP2
#define TCA_SPLIT_CMP_LED3			TCA0.SPLIT.HCMP0

#define ADC0_MUXPOS_REGISTER		ADC0.MUXPOS
#define TCA_PORTMUX_REGISTER		PORTMUX.TCAROUTEA



// Funksjoner
void pin_mode(PORT_t *port, uint8_t pin, uint8_t mode, uint8_t inven, uint8_t pullup);
void pinxctrl_config(PORT_t *port, uint8_t pin, uint8_t pinctrl_bm);
void pinxctrl_reset(PORT_t *port, uint8_t pin);
void pin_enable_interrupt(PORT_t *port, uint8_t pin, char edge);

void set_pin_high(PORT_t *port, uint8_t pin);
void set_pin_low(PORT_t *port, uint8_t pin);

uint8_t digital_read(PORT_t *port, uint8_t pin);

int32_t str_to_int(char *string, uint16_t str_len);
void count_down(uint8_t seconds);


void test_internal_temp_sensor();

#endif /* BOARD_H_ */