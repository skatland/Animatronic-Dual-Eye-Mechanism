// adc.c
#include "adc.h"
#include <avr/io.h>

void ADC_Init(void) {
	VREF.ADC0REF = VREF_REFSEL_VDD_gc;
	ADC0.CTRLC = ADC_PRESC_DIV4_gc;
	ADC0.CTRLA = ADC_ENABLE_bm;
}

uint16_t ADC_Read(uint8_t channel) {
	ADC0.MUXPOS = channel;          
	ADC0.COMMAND = ADC_STCONV_bm;     
	while (!(ADC0.INTFLAGS & ADC_RESRDY_bm)); 
	ADC0.INTFLAGS = ADC_RESRDY_bm;    
	return ADC0.RES;                  
}
