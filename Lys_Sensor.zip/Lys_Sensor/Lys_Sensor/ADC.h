/*
 * ADC.h
 *
 * Created: 5/12/2025 12:26:52 PM
 *  Author: mrbra
 */ 

// adc.h
#ifndef ADC_H_
#define ADC_H_

#include <avr/io.h>

void ADC_Init(void);
uint16_t ADC_Read(uint8_t channel);

#endif // ADC_H_
