#define F_CPU 4000000UL

#include <avr/io.h>
#include <util/delay.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>  // for atoi()
#include "adc.h"

// Define LED pins
#define RED_LED_PIN    PIN2_bm
#define GREEN_LED_PIN  PIN3_bm
#define SENSOR_INPUT_CHANNEL ADC_MUXPOS_AIN3_gc

#define INPUT_BUFFER_SIZE 10

uint16_t light_threshold = 750;  // Starting threshold

void USART0_init(uint32_t baud_rate)
{
    PORTMUX.USARTROUTEA = PORTMUX_USART0_ALT1_gc;

    uint32_t baud = 64 * (uint32_t)F_CPU / (16 * baud_rate);
    USART0.BAUD = (uint16_t) baud;

    USART0.CTRLC = USART_CHSIZE_8BIT_gc;

    PORTA.DIRSET = PIN4_bm; // TX output
    PORTA.DIRCLR = PIN5_bm; // RX input
    PORTA.PIN5CTRL = PORT_PULLUPEN_bm;

    USART0.CTRLB = USART_RXEN_bm | USART_TXEN_bm;
}

void USART0_transmit_char(char c)
{
    while (!(USART0.STATUS & USART_DREIF_bm)) { ; }
    USART0.TXDATAL = c;
}

void USART0_transmit_str(const char* str)
{
    while (*str) {
        USART0_transmit_char(*str++);
    }
}

char USART0_receive_char(void)
{
    while (!(USART0.STATUS & USART_RXCIF_bm)) { ; }
    return USART0.RXDATAL;
}

void USART0_receive_line(char *buffer, uint8_t max_length)
{
    uint8_t i = 0;
    char c = 0;

    while (1) {
        c = USART0_receive_char();

        if (c == '\r' || c == '\n') {  // End on Enter
            buffer[i] = '\0';
            break;
        } else if (i < max_length - 1) {
            buffer[i++] = c;
        }
    }
}

void leds_init(void) {
    PORTA.DIRSET = RED_LED_PIN | GREEN_LED_PIN;
    PORTA.OUTSET = GREEN_LED_PIN;  // Green LED ON
    PORTA.OUTCLR = RED_LED_PIN;    // Red LED OFF
}

int main(void) {
    uint16_t adc_result = 0;
    char buffer[50];
    char input_buffer[INPUT_BUFFER_SIZE];

    leds_init();
    ADC_Init();
    USART0_init(9600);

    USART0_transmit_str("System Initialized\r\n");
    USART0_transmit_str("Type 'h' for help.\r\n");

    while (1) {
        adc_result = ADC_Read(SENSOR_INPUT_CHANNEL);

        if (adc_result > light_threshold) {
            PORTA.OUTSET = RED_LED_PIN;
        } else {
            PORTA.OUTCLR = RED_LED_PIN;
        }

        sprintf(buffer, "ADC: %u, Threshold: %u\r\n", adc_result, light_threshold);
        USART0_transmit_str(buffer);

        // Check for command input
        if (USART0.STATUS & USART_RXCIF_bm) {
            char cmd = USART0_receive_char();

            if (cmd == 't') {
                USART0_transmit_str("Enter new threshold value:\r\n");
                USART0_receive_line(input_buffer, INPUT_BUFFER_SIZE);

                uint16_t new_threshold = (uint16_t) atoi(input_buffer);

                if (new_threshold > 0) {
                    light_threshold = new_threshold;
                    sprintf(buffer, "Threshold updated to: %u\r\n", light_threshold);
                } else {
                    sprintf(buffer, "Invalid input. Threshold unchanged.\r\n");
                }

                USART0_transmit_str(buffer);

            } else if (cmd == 'r') {
                sprintf(buffer, "Current threshold: %u\r\n", light_threshold);
                USART0_transmit_str(buffer);

            } else if (cmd == 'h') {
                USART0_transmit_str("Commands:\r\n");
                USART0_transmit_str("t - Set new threshold (type number after)\r\n");
                USART0_transmit_str("r - Read current threshold\r\n");
                USART0_transmit_str("h - Show help\r\n");

            } else {
                USART0_transmit_str("Unknown command. Type 'h' for help.\r\n");
            }
        }

        _delay_ms(500);
    }
}
