/*
 * USART.h
 *
 * Created: 08.09.2024 14:18:04
 *  Author: Buzz Lightyear
 */ 


#ifndef USART_H_

#define USART_H_


// Includes
#include <avr/io.h>
#include <avr/interrupt.h>
#include "fcpu.h"
#include <stdio.h>
#include <string.h>
#include <util/delay.h>


// Global variables
#define START_CHAR '['
#define STOP_CHAR ']'
extern int STR_RECEIVE_EN;


// Functions
void USART3_init (uint32_t baud_rate);

void USART3_transmit_char ( char c) ;
void USART3_transmit_str (char *str);

char USART3_receive_char () ;
void USART3_receive_str_polling ();
void USART3_receive_str_interrupt ();

void USART2_init();
void USART2_transmit_char(char c);

void USART3_test(uint16_t min, uint16_t max);

void USART2_init_ALT1 (uint32_t baud_rate);
void USART2_transmit_char (char c);
void USART2_transmit_str (char* str);
char USART2_receive_char ();
void USART2_receive_str_interrupt (char* str_out);


// PRINTF GREIER
 static uint8_t USART3_send_char ( char c, FILE * stream ) ;
 static FILE new_std_out = FDEV_SETUP_STREAM ( USART3_send_char , NULL , _FDEV_SETUP_WRITE );
 


#endif /* USART_H_ */