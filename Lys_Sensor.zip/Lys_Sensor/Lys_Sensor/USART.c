/*
 * USART.c
 *
 * Created: 08.09.2024 14:17:45
 *  Author: Buzz Lightyear
 */ 

#include "USART.h"


static uint8_t USART3_send_char (char c, FILE *stream ) 
{
	USART3_transmit_char(c);
	
	return 0;
}


void USART3_init (uint32_t baud_rate)
{
	// BASIC FUNCTION SETUP
	
	uint32_t baud = 64 * (uint32_t)F_CPU / (16*(baud_rate));	
	USART3.BAUD = (uint16_t) baud;
	//USART3.BAUD = 1666; // Manually set baud-setting for 9600 @4MHz 
	
	USART3.CTRLC = USART_CHSIZE_8BIT_gc; // Asynch mode, no parity, 1 stop bit, 8 data bits

	pin_mode(&USART3_PORT, USART3_TXD_PIN_bp, 'O', 0);
	pin_mode(&USART3_PORT, USART3_RXD_PIN_bp, 'O', 0);

	USART3.CTRLB = USART_RXEN_bm | USART_TXEN_bm; 
	
	
	// OTHER FUNCTIONALITY SETUP
	stdout = &new_std_out;
	USART3.CTRLA = (1 << USART_RXCIE_bp); // RX-interrupt enable
	
	//USART3.CTRLA = (1 << USART_LBME_bp); //enable loopback
	printf("\n If readable: USART3 initialized successfully. USART3.BAUD = %u\n", USART3.BAUD);
}

void USART2_init_ALT1 (uint32_t baud_rate)
{
	
	PORTMUX.USARTROUTEA |= PORTMUX_USART2_ALT1_gc; // PF4 og PF5
	
	// BASIC FUNCTION SETUP
	
	uint32_t baud = 64 * (uint32_t)F_CPU / (16*(baud_rate));	
	USART2.BAUD = (uint16_t) baud;
	//USART3.BAUD = 1666; // Manually set baud-setting for 9600 @4MHz 
	
	USART2.CTRLC = USART_CHSIZE_8BIT_gc; // Asynch mode, no parity, 1 stop bit, 8 data bits

	pin_mode(&USART2_PORT, USART2_TXD_PIN_bp, 'O', 0);
	pin_mode(&USART2_PORT, USART2_RXD_PIN_bp, 'I', 0);

	USART2.CTRLB = USART_RXEN_bm | USART_TXEN_bm; 
	
	
	// OTHER FUNCTIONALITY SETUP
	USART2.CTRLA = (1 << USART_RXCIE_bp); // RX-interrupt enable
	
	//USART2.CTRLA |= USART_LBME_bm; //enable loopback
	printf("\n USART2 initialized. USART2.BAUD = %u\n", USART2.BAUD);
}

void USART2_transmit_char (char c)
{
	while( !(USART2.STATUS & USART_DREIF_bm) )
	{
		;
	}
	
	USART2.TXDATAL = c;
}

char USART2_receive_char ()
{
	while (!(USART2.STATUS & USART_RXCIF_bm))
	{
		;
	}
		
	return USART2.RXDATAL;
}

void USART2_transmit_str (char* str)
{
	int len = strlen(str);

	for (int i=0; i<len; i++)
	{
		USART2_transmit_char(str[i]);
	}
}

void USART2_receive_str_interrupt (char* str_out)
{ 
	int buffersize = 255;
	char character; 
	char buffer[buffersize]; 
	int ind = 0; 

	character = USART2_receive_char();
	
	// RECIEVE CHARACTERS UNTIL YOU SEE THE STOP CHARACTER	
	while ((character != STOP_CHAR) && (ind < buffersize-1))
	{
		buffer[ind] = character;
		ind++;
		character = USART2_receive_char();
		//printf("Steg 1.1: %i < %i    %c != %c\n", ind, buffersize-1, character, STOP_CHAR);
	}
	
	buffer[ind] = '\0'; // Terminate str.
	
	strcpy(str_out, buffer);
}



void USART3_transmit_char (char c)
{
	while( !(USART3.STATUS & USART_DREIF_bm) )
	{
		;
	}
	
	USART3.TXDATAL = c;
}


void USART3_transmit_str (char* str)
{
	int len = strlen(str);

	for (int i=0; i<len; i++)
	{
		USART3_transmit_char(str[i]);
	}
}


char USART3_receive_char ()
{
	while (!(USART3.STATUS & USART_RXCIF_bm))
	{
		;
	}
		
	return USART3.RXDATAL;
}


void USART3_receive_str_polling (char* str_out, int buffersize)
{ 
	const int max_buffer_size = 255;
	char character; // Stores most recently received character
	char buffer[buffersize]; // Stores received characters
	int ind = 0; // Counts no. received characters
	
	
	// VERIFY BUFFERSIZE
	if (buffersize > max_buffer_size)
	{
		strcpy(str_out, "Error: Buffer size is too big.\n");
		return;
	}
	
	// WAIT FOR START CHARACTER
	do 
	{
		character = USART3_receive_char();
	} 
	while (character != START_CHAR);
		
	character = USART3_receive_char();
	
	// RECIEVE CHARACTERS UNTIL YOU SEE THE STOP CHARACTER	
	while ((character != STOP_CHAR) && (ind < buffersize-1))
	{
		buffer[ind] = character;
		ind++;
		character = USART3_receive_char();
	}
	
	buffer[ind] = '\0'; // Terminate str.
	
	strcpy(str_out, buffer);
}


void USART3_receive_str_interrupt (char* str_out)
{ 
	int buffersize = 255;
	char character; 
	char buffer[buffersize]; 
	int ind = 0; 

	character = USART3_receive_char();
	
	// RECIEVE CHARACTERS UNTIL YOU SEE THE STOP CHARACTER	
	while ((character != STOP_CHAR) && (ind < buffersize-1))
	{
		buffer[ind] = character;
		ind++;
		character = USART3_receive_char();
	}
	
	buffer[ind] = '\0'; // Terminate str.
	
	strcpy(str_out, buffer);
}


void USART3_test(uint16_t min, uint16_t max)
{
	uint16_t old_baud = USART3.BAUD;
	
	for (int i=min; i<=max; i++)
	{
		USART3.BAUD = i;
		_delay_ms(50);
		printf("\nBAUD: %d!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n", i);
	}
	
	printf("Old baud: %u", old_baud);
}