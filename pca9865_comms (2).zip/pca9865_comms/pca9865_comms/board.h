/*
 * board.h
 *
 * Created: 11.11.2024 16:25:10
 *  Author: Buzz Lightyear
 */ 


#ifndef BOARD_H_
#define BOARD_H_

#include <avr/io.h>
#include "includes.h"
#include <avr/io.h>
#include "fcpu.h"

#define USART1PORT				PORTC
#define IO_PORT					PORTD
#define I2CPORT					PORTA


#define IOPORT_vect			PORTD_PORT_vect

#define ANALOG1_PIN_bp			PIN1_bp
#define ANALOG4_PIN_bp			PIN4_bp

#define IO2_PIN_bp				PIN2_bp
#define IO3_PIN_bp				PIN3_bp

#define SDA_PIN_bp				PIN2_bp
#define SCL_PIN_bp				PIN3_bp

#define USART1_TXD_PIN_bp		PIN0_bp
#define USART1_RXD_PIN_bp		PIN1_bp


// Funksjoner
void pin_mode(PORT_t *port, uint8_t pin, uint8_t mode, uint8_t inven, uint8_t pullup);
void pinxctrl_config(PORT_t *port, uint8_t pin, uint8_t pinctrl_bm);
void pinxctrl_reset(PORT_t *port, uint8_t pin);
void pin_enable_interrupt(PORT_t *port, uint8_t pin, char edge);

void set_pin_high(PORT_t *port, uint8_t pin);
void set_pin_low(PORT_t *port, uint8_t pin);

uint8_t digital_read(PORT_t *port, uint8_t pin);


#endif /* BOARD_H_ */