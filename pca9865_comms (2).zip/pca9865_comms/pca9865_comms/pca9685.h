/*
 * pca9685.h
 *
 * Created: 26.05.2025 16:13:19
 *  Author: sigve
 */ 

#ifndef PCA9685_H_
#define PCA9685_H_
#include <stdint.h>

void pca9685_init(void); 
void pca9685_set_pwm_freq(uint8_t addr, float freq);
void pca9685_set_pwm(uint8_t addr, uint8_t channel, uint16_t on, uint16_t off);
void pca9685_set_servo_angle(uint8_t addr, uint8_t channel, uint8_t angle);

#endif
