/*
 * pca9685.c
 *
 * Created: 26.05.2025 16:13:51
 *  Author: sigve
 */ 

#include "board.h"
#include "fcpu.h"
#include "pca9685.h"
#include "i2c.h"
#include <util/delay.h>
#include <stdint.h>


#define PCA9685_ADDRESS 0x40
#define MODE1 0x00
#define PRESCALE 0xFE
#define LED0_ON_L 0x06



void pca9685_init(void) {
	
	// Trinn 1: Sett PCA9685 i sleep-mode for � skrive prescaler
	i2c_start(PCA9685_ADDRESS);
	
	i2c_write(MODE1);
	i2c_write(0x10); // Sleep-bit = 1
	i2c_stop();
	
	_delay_ms(1);

	// Trinn 2: Skriv prescaler for 50 Hz
	i2c_start(PCA9685_ADDRESS);
	i2c_write(PRESCALE);
	i2c_write(121);
	i2c_stop();

	_delay_ms(1);

	// Trinn 3: Wake PCA9685 opp igjen
	i2c_start(PCA9685_ADDRESS);
	i2c_write(MODE1);
	i2c_write(0x00); // Sleep-bit = 0
	i2c_stop();

	_delay_ms(1);

	// Trinn 4: Sl� p� auto-increment (valgfritt men anbefalt)
	i2c_start(PCA9685_ADDRESS);
	i2c_write(MODE1);
	i2c_write(0b00100000); // AI = 1
	i2c_stop();

	_delay_ms(1);
}


void pca9685_set_pwm(uint8_t addr, uint8_t channel, uint16_t on, uint16_t off) {
	i2c_start(addr);
	i2c_write(LED0_ON_L + 4 * channel);
	i2c_write(on & 0xFF);
	i2c_write(on >> 8);
	i2c_write(off & 0xFF);
	i2c_write(off >> 8);
	i2c_stop();
}

void pca9685_set_servo_angle(uint8_t addr, uint8_t channel, uint8_t angle) {
	// Tilpasset DF9GMS: 0.5�2.5 ms ? 102�512 steg
	uint16_t pulse = (uint16_t)(102 + ((float)angle / 180.0) * (512 - 102));
	pca9685_set_pwm(addr, channel, 0, pulse);
}
