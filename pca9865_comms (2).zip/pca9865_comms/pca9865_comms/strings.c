/*
 * string_handling.c
 *
 * Created: 27.02.2025 12:06:22
 *  Author: Buzz Lightyear
 */ 


#include "strings.h"


SplitStrStruct split_string(char* string, char* delim)
{
	SplitStrStruct splitStr;
	
	int ind = 0;
	splitStr.tokens[ind] = strtok(string, delim);
	
	
	while (splitStr.tokens[ind] != NULL)
	{
		ind++;
		splitStr.tokens[ind] = strtok(NULL, delim);
	}
	
	splitStr.length = ind;
	
	return splitStr;
}


int32_t str_to_int(char *string, uint16_t str_len){
	
	uint32_t sum = 0;
	
	for (int char_ind = 0; char_ind < str_len; char_ind++)
	{
		
		uint16_t char_val = (uint16_t) string[char_ind];
		
		if ('0' <= char_val && char_val <= '9') 
		{ 
			
			char_val -= '0'; // Get value of digit.
			
			// Digit * 10 ^ X
			for (int i = 0; i < str_len - (char_ind + 1); i++)
			{
				char_val *= 10;
			}
			sum += char_val;
			
		}
		else
		{
			return -1;
		}
		
	}

	return (int32_t)sum;
	
}