/*
 * i2c.c
 *
 * Created: 26.05.2025 16:12:11
 *  Author: sigve
 */ 

#include <avr/io.h>
#include "fcpu.h"
#include "i2c.h"
#include "board.h"

void i2c_init(void) {
	TWI0.MBAUD = 72;							++// 100kHz @ 16MHz
	TWI0.MCTRLA = TWI_ENABLE_bm;                // Enable TWI
	TWI0.MSTATUS = TWI_BUSSTATE_IDLE_gc;        // Set bus state to idle
}

uint8_t i2c_start(uint8_t address) {
	

	TWI0.MADDR = (address << 1); // Write mode
	
	while (!(TWI0.MSTATUS & (TWI_WIF_bm | TWI_RIF_bm))) // Wait for ACK/NACK
	{	
	}
	
	return !(TWI0.MSTATUS & TWI_RXACK_bm); // Return 1 if ACK received
}

uint8_t i2c_write(uint8_t data) {
	TWI0.MDATA = data;
	while (!(TWI0.MSTATUS & TWI_WIF_bm)) // Wait for write complete
	{
	}
	return !(TWI0.MSTATUS & TWI_RXACK_bm); // Return 1 if ACK
}

void i2c_stop(void) {
	TWI0.MCTRLB = TWI_MCMD_STOP_gc;
}
