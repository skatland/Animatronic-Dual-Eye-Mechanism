/*
 * strings.h
 *
 * Created: 27.02.2025 12:11:50
 *  Author: Buzz Lightyear
 */ 


#ifndef STRINGS_H_
#define STRINGS_H_

#include <stdio.h>
#include <string.h>
#include <util/delay.h>

typedef struct
{
	char* tokens[20];
	int length;
}SplitStrStruct;


SplitStrStruct split_string(char* string, char* delim);



#endif /* STRINGS_H_ */